#ifndef DATA_H
#define DATA_H
typedef struct Data
{
	int value;
} Data;
#endif
