#ifndef PROFILE_H
#define PROFILE_H

void profileInsert(Vector *array, List *list);
void profileRead(Vector *array, List *list);
void profileRemove(Vector *array, List *list);

#endif
